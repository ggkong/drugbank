#encoding=utf-8

from django.http import JsonResponse
from django.shortcuts import render
import time
num_progress = 0 # 当前的后台进度值（不喜欢全局变量也可以很轻易地换成别的方法代替）




'''
展示界面 UI
'''


def show_progress1(request):
    # return JsonResponse(num_progress, safe=False)
    return render(request, 'progress.html')



'''
后台实际处理程序
'''


def process_data(request):

    global num_progress
    print('开始当访问 progress_data')
    for i in range(10000000):
        # ... 数据处理业务
        num_progress = i * 100 / 10000000  # 更新后台进度值，因为想返回百分数所以乘100
        res = num_progress
    return JsonResponse(res, safe=False)
'''
前端JS需要访问此程序来更新数据
'''


def show_progress(request):
    print('show_progress----------'+str(num_progress))
    return JsonResponse(num_progress, safe=False)