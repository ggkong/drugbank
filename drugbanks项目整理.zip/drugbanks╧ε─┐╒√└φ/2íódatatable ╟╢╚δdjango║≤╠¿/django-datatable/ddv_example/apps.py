from django.apps import AppConfig


class DdtConfig(AppConfig):
    name = 'ddt'
