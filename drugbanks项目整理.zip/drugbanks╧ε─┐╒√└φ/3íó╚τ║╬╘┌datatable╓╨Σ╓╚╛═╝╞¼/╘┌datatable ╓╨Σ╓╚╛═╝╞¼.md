需求：在datatable 中渲染图片 

解决方案:

1、在js databtable 中加入  将对象渲染成图片 其中代码第二行 的width :400px 代表图片占整个表宽度的400px

imgscr 将会由后台来进行提供   提供的信息将会被写在model 对象的属性中去

```js
{
                data: 'imgscr',
                "width": "400px",
                 render: function (data, type, row, meta) {                                               
     return "<img style = 'width:300px;height:200px;transition:all 1s;' src='" + data + "' />";
                      //还可以给图片加上超链接
                     //return "<a href='" + data + "'>" + data + "</a>";
                },
                orderable: false,
                searchable: true,
                className: "center"
            },
```

2、具体的代码将会放在：

https://github.com/ggkong/django-datatable--demo