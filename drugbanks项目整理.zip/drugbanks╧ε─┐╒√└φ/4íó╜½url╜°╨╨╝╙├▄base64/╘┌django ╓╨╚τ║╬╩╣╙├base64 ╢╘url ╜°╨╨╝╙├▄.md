需求：需要对 url 进行加密 

解决方案：引用base64 进行加密 和 解密

在网页中进行加密的方式：

其中 a 为将要进行 加密的值  

window.open 为将要调转到到的 网页的url

```js
 <script>
            function toNew(a) {
                var b = btoa(a);
                window.open("../../raw/" + b + "/");
            }
 </script>
```



在后台中进行加密的方式为：

drug.de_id 为将要进行加密的内容

首先将要进行加密的内容进行 str （）

然后将str 转化为utf-8 的编码方式

最后将对象进行加密

最后将加密的内容进行 utf-8 的编码

```python
base64_de_id = str(drug.de_id)
encoding_de_id = base64_de_id.encode('utf-8')
p = base64.b64encode(encoding_de_id)
base_p = str(p, encoding='utf-8')
```

后台进行解密的方式为：

其中de_id 为将要进行解密的内容

```python
base64.b64decode(de_id).decode('ascii')
```

更详细的使用方法在：

https://blog.csdn.net/kongge123456/article/details/104882157