源码地址：

https://github.com/ggkong/js

里面介绍了一些关于chart.js 的内容