from django.shortcuts import render
from django.shortcuts import HttpResponse
import subprocess
from . import models
from itertools import chain
from operator import attrgetter


# 搜索方法在三个子孙中搜索
def search_in_one_two_three_by_id(de_id):
    # 利用循环 搜索所有在表一中的子和孙：
    a = 0
    sondrugs = []
    s_de_id = de_id
    print(s_de_id)
    leveltwos = models.LevelTwo.objects.filter(parent_id = s_de_id)
    for two in leveltwos:
        sondrugs.append(two)
        levelthrees = models.LevelThree.objects.filter(parent_id = two.de_id)
        for three in levelthrees:
            sondrugs.append(three)
        # 将threes 置空
        threes = []
    for num in sondrugs:
        a = a + 1
    print('在子表中共有{}个对象'.format(a))
    return sondrugs

def createfile():
    ones = models.LevelOne.objects.all()
    # print(ones)
    for one in ones:
        print(one.de_id)
        sondrugs = search_in_one_two_three_by_id(one.de_id)
        txts = sorted(chain(sondrugs),key=attrgetter('logP'),reverse=True)
        print('现在生成{}的子表文件'.format(one.de_id))
        with open('../../../../../cloud/server/static/txt/'+ one.de_id +'.txt','w') as f:
            for i in txts:
                new_context = str(i)
                f.write(new_context)
        f.close()
                
# de_id = 'DE209840'
def display02(request,de_id):
    # 修改部分
    createfile()


    # sondrugs = search_in_one_two_three_by_id('DE991')
    # last = sorted(chain(sondrugs), key=attrgetter('logP'), reverse=True)
    

    # for i in sondrugs:
        # print(i)
    # print(sondrugs)    
    
    # print('现在即将生成文件')
    # with open('../../../../../cloud/server/static/txt/de991.txt','w') as f:
    #     for i in last:
    #         # 模型的str 方法 最后包含一个 '/n'
    #         new_context = str(i)
    #         f.write(new_context)
        


    # 在三个数据库中搜索对象
    
    if models.LevelOne.objects.filter(de_id = de_id):
        # sondrugs = search_in_one_two_three_by_id(de_id)
        print('deid 来自第一个数据库')
        drug = models.LevelOne.objects.get(de_id = de_id)
        
        return render(request,'cycles/display02.html',{'drug':drug})
        
    if models.LevelTwo.objects.filter(de_id = de_id):
        print('de_id 来自第二个数据库')
        drug = models.LevelTwo.objects.get(de_id = de_id)
        # return render(request,'cycles/display02.html',{'drug':drug})
        return render(request,'cycles/parents.html')
    if models.LevelThree.objects.filter(de_id = de_id):
        print('de_id 来自第三个数据库')
        drug = models.LevelThree.objects.get(de_id = de_id)
        return render(request,'cycles/display02.html',{'drug':drug})
    
    else:
        return render(request,'404.html')



def list(request):
    leone =  models.LevelOne.objects.get(de_id = 'DE991')
    drugs = models.LevelTwo.objects.filter(parent_id = 'DE991')
    print(leone.de_id)
    return render(request, 'cycles/list.html',{'drugs':drugs,'leone':leone})


def dispose_txt():
    results = {}
    
    with open('../../../../../cloud/server/static/searchtxt/fouts.txt','r') as f:
    # with open('/cloud/server/static/txt/fouts.txt', 'r') as f:
        for eachLine in f.readlines():
            data = eachLine.split('\t')
            data[1] = data[1].replace('\n', '')
            results[data[0]] = data[1]
    return results

def waterfull(request):
    de_id = 'DE209840'
    smiles = "'Cc1ccc2c(Nc3ccc(CN4CCN(C)CC4)c(C(F)(F)F)c3)noc2c1C#Cc1cnc2cccnn12'"
    top_num = 30
    search(smiles,de_id,top_num)
    # 得到解析数据
    de_ids = []
    imgsrc = []
    similarity = []
    
    img_similarity_drugs = dispose_txt()
    
    # tess = 'search/DE209840/30/DE325610.svg'
    for key in img_similarity_drugs:
        a = key
        de_ids.append(a)
        b = 'search/DE209840/30/'+key+'.svg'
        imgsrc.append(b)
        c = img_similarity_drugs[key]
        similarity.append(c)
    
    # for key,value in img_similarity_drugs:
    #     c = similarity_drugs[key]
    #     similarity.append(c)

    print(de_ids)    
    print(similarity)
    print(imgsrc)
    
    return render(request,'query/waterfull.html',{'de_ids':de_ids,'imgsrc':imgsrc,'similarity':similarity})
    
   


def display1(smiles,de_id):
    cmd_type = ''
    display_tmp_path = '/cloud/server/static/display1/'#可选参数
    fout_path = 'fouts.txt'
    cmd = "/soft/conda/envs/rdkit-python-3.6/bin/python /drugbanks/bin/drugbanks_exe.py -c Display -d One -s "
    cmd += smiles + " -i " + de_id + " -x " + display_tmp_path
    ex = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out, err  = ex.communicate()
    status = ex.wait()



def display2(smiles,de_id,ns_id,parent_id):
    cmd_type = ''
    display_tmp_path = '/cloud/server/static/display2/'#可选参数
    # search_tmp_base_path = '/drugbanks/tmp/'#可选参数
    fout_path = '/cloud/server/static/displaytxt/fouts.txt'
    cmd = "/soft/conda/envs/rdkit-python-3.6/bin/python /drugbanks/bin/drugbanks_exe.py -c Display -d Others -s "        
    cmd += smiles + " -i " + de_id + " -p " + parent_id + " -n " + ns_id + " -f " + fout_path + " -x " + display_tmp_path
    ex = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out, err  = ex.communicate()
    status = ex.wait()



def search(smiles, de_id, top_num):
    cmd_type = ''
    # display_tmp_path = '/drugbanks/tmp/'#可选参数
    search_tmp_base_path = '/cloud/server/static/search/'#可选参数
    fout_path = '/cloud/server/static/searchtxt/fouts.txt'
    cmd = "/soft/conda/envs/rdkit-python-3.6/bin/python /drugbanks/bin/drugbanks_exe.py -c Search -s "
    smiles = "'Cc1ccc2c(Nc3ccc(CN4CCN(C)CC4)c(C(F)(F)F)c3)noc2c1C#Cc1cnc2cccnn12'"
    de_id = 'DE209840'
    cmd += smiles + " -t " + str(top_num) + " -f " + fout_path + " -i " + de_id + " -y " + search_tmp_base_path
    ex = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    out, err  = ex.communicate()
    status = ex.wait()
