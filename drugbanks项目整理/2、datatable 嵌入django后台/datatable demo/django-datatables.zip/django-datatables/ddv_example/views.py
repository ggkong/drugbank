# -*- coding: utf8 -*-
from django.contrib.auth.models import User
from django.db.models import Q
from django.views.generic import TemplateView
from django_datatables_view.base_datatable_view import BaseDatatableView

from ddv_example.models import TestModel, ChildAndGrandModel, ChildAndGrandAndSvgModel


class IndexView(TemplateView):
    template_name = 'ddv_example/index.html'


class UsersList110(TemplateView):
    template_name = 'ddv_example/users_list_1_10.html'


class UsersList110Json(BaseDatatableView):
    model = User
    total_records = -1
    total_display_records = -1
    
    def get_initial_queryset(self):
        print(self.request.GET)
        propeties = {#这个地方写上表格的列序号和真实抬头之间的对应关系，下面好order_by使用名称
            '0': 'username',
            '1': 'password'
        }
        
        draw = self.request.GET.get('draw')
        order_column = self.request.GET.get('order[0][column]')
        order_dir = self.request.GET.get('order[0][dir]')
        start = int(self.request.GET.get('start'))
        length = int(self.request.GET.get('length'))
        de_id = self.request.GET.get('de_id')
        data_start_len = 2#这两个值实际中根据de_id查询真实的位置
        date_end_len = 5
        
        print(draw, order_column, order_dir, start, length, de_id, data_start_len, date_end_len)
        
        order_name = propeties[order_column]
        if order_dir == 'desc':
            order_name = '-' + order_name
            
        original_all_data = self.model.objects.filter(id__gte=data_start_len, id__lte=date_end_len).order_by(order_name)
        
        self.total_records = self.total_display_records = original_all_data.count()
        
        all_data = []
        for ind in range(start, start + length):
            if ind >= self.total_records:
                break
            d = original_all_data[ind]
            child_or_grand = ChildAndGrandAndSvgModel(
                username = d.username,
                password = d.password,
                imgpath = '/static/ddv_example/test.gif'
            )
            all_data.append(child_or_grand)
        
        return all_data
    
    def filter_queryset(self, qs):
        return qs
    
    def get_context_data(self, *args, **kwargs):
        try:
            self.initialize(*args, **kwargs)

            # prepare columns data (for DataTables 1.10+)
            self.columns_data = self.extract_datatables_column_data()

            # determine the response type based on the 'data' field passed from JavaScript
            # https://datatables.net/reference/option/columns.data
            # col['data'] can be an integer (return list) or string (return dictionary)
            # we only check for the first column definition here as there is no way to return list and dictionary
            # at once
            self.is_data_list = True
            if self.columns_data:
                self.is_data_list = False
                try:
                    int(self.columns_data[0]['data'])
                    self.is_data_list = True
                except ValueError:
                    pass

            # prepare list of columns to be returned
            self._columns = self.get_columns()

            # prepare initial queryset
            qs = self.get_initial_queryset()

            # store the total number of records (before filtering)
            #total_records = qs.count()

            # apply filters
            #qs = self.filter_queryset(qs)

            # number of records after filtering
            #total_display_records = qs.count()

            # apply ordering
            #qs = self.ordering(qs)

            # apply pagintion
            #qs = self.paging(qs)
            print(qs)

            # prepare output data
            if self.pre_camel_case_notation:
                aaData = self.prepare_results(qs)

                ret = {'sEcho': int(self._querydict.get('sEcho', 0)),
                       'iTotalRecords': self.total_records,
                       'iTotalDisplayRecords': self.total_display_records,
                       'aaData': aaData
                       }
            else:
                data = self.prepare_results(qs)

                ret = {'draw': int(self._querydict.get('draw', 0)),
                       'recordsTotal': self.total_records,
                       'recordsFiltered': self.total_display_records,
                       'data': data
                       }
            print(ret)
            return ret
        except Exception as e:
            return self.handle_exception(e)        

class TestModelList(TemplateView):
    template_name = 'ddv_example/testmodel_list.html'


class TestModelListJson(BaseDatatableView):
    model = TestModel
    # columns and order columns are provided by datatables in the request using "data" in columns definition


# backward compatibility with Datatables 1.9.x
class UsersList(TemplateView):
    template_name = 'ddv_example/users_list.html'


class UsersListJson(BaseDatatableView):
    model = User
    columns = ['username', 'email']
    order_columns = ['username', 'email']

    def filter_queryset(self, qs):
        sSearch = self.request.GET.get('sSearch', None)
        if sSearch:
            qs = qs.filter(Q(username__istartswith=sSearch) | Q(email__istartswith=sSearch))
        return qs
