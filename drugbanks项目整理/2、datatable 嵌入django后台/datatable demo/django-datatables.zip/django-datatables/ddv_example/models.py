from django.db import models


class TestModel(models.Model):
    name = models.CharField('Name', max_length=50, default='', blank=False)
    description = models.TextField('Description', default='')

    @property
    def testproperty(self):
        return '{} testprop'.format(self.name)

class ChildAndGrandModel(models.Model):
    username = models.CharField('UserName', max_length=100, default='', blank=False)
    password = models.CharField('PassWord', max_length=200, default='', blank=False)
    
    def __str__(self):
        return self.username
    
class ChildAndGrandAndSvgModel(ChildAndGrandModel):
    imgpath = models.CharField('ImgPath', max_length=500, default='', blank=False)
    
    def __str__(self):
        return self.imgpath